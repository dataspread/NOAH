Directory structure
---"design iterations.pdf": screenshots of different stages of NOAH's design process with explanations.
---"Spreadsheet Navigation Study_Quiz Tasks.pdf": describes the tasks used during the quiz phase of the user study.
---"Supplementary Materials_Participant Packet for Spreadsheet Navigation Evaluation Study.pdf": describes three surveys conducted during the study.
---"Supplementary Materials_Spreadsheet Navigation Evaluation Study Protocol.pdf": describes the study protocol.